# Poker Knowledge Base v1

This package contains a first-pass JSON-schema-driven knowledge base scaffold for a poker training and hand analysis product.

## Structure
- `schemas/`: JSON Schemas for each entity type
- `templates/`: empty collection templates and a manifest template
- `data/`: starter sample data files for each entity collection

## Core flow
`spot -> board_class -> baseline strategy -> exploit adjustment -> leak -> narrative -> reminder`

## Recommended loading order
1. hand_buckets
2. opponents
3. spots
4. board_classes
5. strategy_rules
6. exploit_rules
7. leaks
8. narratives
9. reminders
10. scenarios

## Notes
- IDs should be stable and human-readable.
- Keep user-facing Chinese copy in dedicated fields.
- Use `source_meta` to track provenance for anything derived from solver work or internal curation.
